import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminsideServiceService } from 'src/app/service/adminside-service.service';
import { NgToastService } from 'ng-angular-popup';

@Component({
  selector: 'app-add-mission',
  templateUrl: './add-mission.component.html',
  styleUrls: ['./add-mission.component.css']
})
export class AddMissionComponent implements OnInit {
  addMissionForm: FormGroup;
  endDateDisabled: boolean = true;
  regDeadlineDisabled: boolean = true;
  formValid: boolean;
  countryList: any[] = [];
  cityList: any[] = [];
  missionThemeList: any[] = [];
  missionSkillList: any[] = [];
  formData = new FormData();
  docFormData = new FormData();
  imageListArray: any[] = [];
  documentListArray: any[] = [];

  constructor(
    public fb: FormBuilder,
    public service: AdminsideServiceService,
    public toastr: ToastrService,
    public router: Router,
    public datePipe: DatePipe,
    private toast: NgToastService
  ) { }

  ngOnInit(): void {
    this.addMissionFormValid();
    this.setStartDate();
    this.CountryList();
    this.GetMissionSkillList();
    this.GetMissionThemeList();
  }

  addMissionFormValid() {
    this.addMissionForm = this.fb.group({
      countryId: [null, Validators.compose([Validators.required])],
      cityId: [null, Validators.compose([Validators.required])],
      missionTitle: [null, Validators.compose([Validators.required])],
      missionDescription: [null, Validators.compose([Validators.required])],
      missionOrganisationName: [null, Validators.compose([Validators.required])],
      missionOrganisationDetail: [null, Validators.compose([Validators.required])],
      startDate: [null, Validators.compose([Validators.required])],
      endDate: [null, Validators.compose([Validators.required])],
      missionThemeId: [null, Validators.compose([Validators.required])],
      missionSkillId: [null, Validators.compose([Validators.required])],
      missionType: [null, Validators.compose([Validators.required])],
      totalSheets: [null, Validators.compose([Validators.required])],
      registrationDeadLine: [null, Validators.compose([Validators.required])],
      missionAvilability: [null, Validators.compose([Validators.required])],
      missionImages: [null, Validators.compose([Validators.required])],
      missionDocuments: [null, Validators.compose([Validators.required])],
      missionVideoUrl: [null, Validators.compose([Validators.required])],
      //missionStatus: [null, Validators.compose([Validators.required])], //?Active/inactive select
      //missionApplyStatus: [null, Validators.compose([Validators.required])],
      //missionApproveStatus: [null, Validators.compose([Validators.required])],
      //missionDateStatus: [null, Validators.compose([Validators.required])],
      //missionDeadLineStatus: [null, Validators.compose([Validators.required])],
      //missionFavouriteStatus: [null, Validators.compose([Validators.required])],

  /*     "createdDate": "2024-06-01T14:22:20.851Z",
   "modifiedDate": "2024-06-01T14:22:20.851Z",
   "isDeleted": true,                                    HANDLED AT BACKEND*/
  // "countryName": "string",                            ?
  // "cityName": "string",                               ?
  // "missionThemeName": "string",                       ?
  // "missionSkillName": "string",                       ?
  // "missionStatus": "string",                          ?Active/inactive select
  // "rating": 0                                          // 0 by default
    });
  }

  get countryId() { return this.addMissionForm.get('countryId') as FormControl; }
  get cityId() { return this.addMissionForm.get('cityId') as FormControl; }
  get missionTitle() { return this.addMissionForm.get('missionTitle') as FormControl; }
  get missionDescription() { return this.addMissionForm.get('missionDescription') as FormControl; }
  get startDate() { return this.addMissionForm.get('startDate') as FormControl; }
  get endDate() { return this.addMissionForm.get('endDate') as FormControl; }
  get missionThemeId() { return this.addMissionForm.get('missionThemeId') as FormControl; }
  get missionSkillId() { return this.addMissionForm.get('missionSkillId') as FormControl; }
  get missionImages() { return this.addMissionForm.get('missionImages') as FormControl; }
  get totalSheets() { return this.addMissionForm.get('totalSheets') as FormControl; }
  get missionOrganisationName() { return this.addMissionForm.get('missionOrganisationName') as FormControl; }
  get missionOrganisationDetail() { return this.addMissionForm.get('missionOrganisationDetail') as FormControl; }
  get missionType() { return this.addMissionForm.get('missionType') as FormControl; }
  get registrationDeadLine() { return this.addMissionForm.get('registrationDeadLine') as FormControl; }
  get missionAvilability() { return this.addMissionForm.get('missionAvilability') as FormControl; }
  get missionVideoUrl() { return this.addMissionForm.get('missionVideoUrl') as FormControl; }
 // get missionStatus() { return this.addMissionForm.get('missionStatus') as FormControl; }
  //get missionApplyStatus() { return this.addMissionForm.get('missionApplyStatus') as FormControl; }
  //get missionApproveStatus() { return this.addMissionForm.get('missionApproveStatus') as FormControl; }
  //get missionDateStatus() { return this.addMissionForm.get('missionDateStatus') as FormControl; }
  //get missionDeadLineStatus() { return this.addMissionForm.get('missionDeadLineStatus') as FormControl; }
  //get missionFavouriteStatus() { return this.addMissionForm.get('missionFavouriteStatus') as FormControl; }
  get missionDocuments() { return this.addMissionForm.get('missionDocuments') as FormControl; }


  setStartDate() {
    const today = new Date();
    const todayString = today.toISOString().split('T')[0];

    this.addMissionForm.patchValue({
      startDate: todayString
    });
    this.endDateDisabled = false;
    this.regDeadlineDisabled = false;
  }

  CountryList() {
    this.service.CountryList().subscribe((data: any) => {
      if (data.result == 1) {
        this.countryList = data.data;
      } else {
        this.toast.error({ detail: "ERROR", summary: data.message, duration: 3000 });
      }
    });
  }

  CityList(countryId: any) {
    countryId = Number(countryId.target.value);
    this.service.CityList(countryId).subscribe((data: any) => {
      if (data.result == 1) {
        this.cityList = data.data;
      } else {
        this.toast.error({ detail: "ERROR", summary: data.message, duration: 3000 });
      }
    });
  }

  GetMissionSkillList() {
    this.service.GetMissionSkillList().subscribe((data: any) => {
      if (data.result == 1) {
        this.missionSkillList = data.data;
      } else {
        this.toast.error({ detail: "ERROR", summary: data.message, duration: 3000 });
      }
    }, err => this.toast.error({ detail: "ERROR", summary: err.message, duration: 3000 }))
  }

  GetMissionThemeList() {
    this.service.GetMissionThemeList().subscribe((data: any) => {
      if (data.result == 1) {
        this.missionThemeList = data.data;
      } else {
        this.toast.error({ detail: "ERROR", summary: data.message, duration: 3000 });
      }
    }, err => this.toast.error({ detail: "ERROR", summary: err.message, duration: 3000 }))
  }

  OnSelectedImage(event: any) {
    const files = event.target.files;
    if (this.imageListArray.length > 5) {
      return this.toast.error({ detail: "ERROR", summary: "Maximum 5 images can be added.", duration: 3000 });
    }
    if (files) {
      this.formData = new FormData();
      for (const file of files) {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.imageListArray.push(e.target.result);
        }
        reader.readAsDataURL(file)
      }
      for (let i = 0; i < files.length; i++) {
        this.formData.append('file', files[i]);
        this.formData.append('moduleName', 'Mission');
      }
      // console.log(this.formData);
    }
  }
  OnSelectedDocument(event: any) {
    const files = event.target.files;
    if (this.documentListArray.length > 5) {
      return this.toast.error({ detail: "ERROR", summary: "Maximum 5 docs can be added.", duration: 3000 });
    }
    if (files) {
      this.docFormData = new FormData();
      for (const file of files) {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.documentListArray.push(e.target.result);
        }
        reader.readAsDataURL(file)
      }
      for (let i = 0; i < files.length; i++) {
        this.docFormData.append('file', files[i]);
        this.docFormData.append('moduleName', 'MissionDoc');
      }
      // console.log(this.docFormData);
    }
  }

  async OnSubmit() {
    this.formValid = true;
    let imageUrl: any[] = [];
    let docUrl: any[] = [];
    let value = this.addMissionForm.value;
    value.missionSkillId = Array.isArray(value.missionSkillId) ? value.missionSkillId.join(',') : value.missionSkillId;
    if (this.addMissionForm.valid) {
      console.log("working 1")
      if (this.imageListArray.length > 0) {
        await this.service.UploadImage(this.formData).pipe().toPromise().then((res: any) => {
          if (res.result == 1) {
            imageUrl = res.data;
          }
        }, err => { this.toast.error({ detail: "ERROR", summary: err.message, duration: 3000 }) });
      }
      if (this.documentListArray.length > 0) {
        await this.service.UploadImage(this.docFormData).pipe().toPromise().then((res: any) => {
          if (res.result == 1) {
            docUrl = res.data;
          }
        }, err => { this.toast.error({ detail: "ERROR", summary: err.message, duration: 3000 }) });
      }
      let imgUrlList = imageUrl.map(e => e.replace(/\s/g, "")).join(",");
      let docUrlList = docUrl.map(e => e.replace(/\s/g, "")).join(",");
      value.missionImages = imgUrlList;
      value.missionDocuments = docUrlList;
      this.service.AddMission(value).subscribe((data: any) => {

        if (data.result == 1) {
          this.toast.success({ detail: "SUCCESS", summary: data.data, duration: 3000 });
          setTimeout(() => {
            this.router.navigate(['admin/mission']);
          }, 1000);
        }
        else {
          this.toast.error({ detail: "ERROR", summary: data.message, duration: 3000 });
        }
      });
      this.formValid = false;
    }
  }

  OnCancel() {
    this.router.navigateByUrl('admin/mission');
  }

  OnRemoveImages(item: any) {
    const index: number = this.imageListArray.indexOf(item);
    if (item !== -1) {
      this.imageListArray.splice(index, 1);
    }
  }
  OnRemoveDocs(item: any) {
    const index: number = this.documentListArray.indexOf(item);
    if (item !== -1) {
      this.documentListArray.splice(index, 1);
    }
  }
}
